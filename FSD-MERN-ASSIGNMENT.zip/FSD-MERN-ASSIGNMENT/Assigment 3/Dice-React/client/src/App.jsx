import { useState } from 'react'

import DiceX from './Components/DiceX'

function App() {
  
  return (
    <>
      <DiceX/>

    </>
  )
}   

export default App
