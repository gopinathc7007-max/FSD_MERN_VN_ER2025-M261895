import { useState } from 'react'


import Quotes from './Components/Quotes'

function App() {
  
  return (
    <>
      <Quotes/>

    </>
  )
}   

export default App
