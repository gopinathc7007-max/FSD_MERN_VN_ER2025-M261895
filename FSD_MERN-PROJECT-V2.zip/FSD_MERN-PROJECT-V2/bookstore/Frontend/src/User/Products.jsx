import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Unavbar from './Unavbar';
import { Link } from 'react-router-dom';

function Products() {
  const [items, setItems] = useState([]);
  const [wishlist, setWishlist] = useState([]);
  const user = JSON.parse(localStorage.getItem('user'));

  useEffect(() => {
    fetchProducts();
    if (user) {
      fetchWishlist();
    }
  }, []);

  const fetchProducts = () => {
    axios.get(`http://localhost:4000/item`, { withCredentials: true })
      .then((res) => setItems(res.data))
      .catch((err) => console.error('Error fetching items:', err));
  };

  const fetchWishlist = () => {
    axios.get(`http://localhost:4000/wishlist/${user.id}`, { withCredentials: true })
      .then((res) => setWishlist(res.data))
      .catch((err) => console.error('Error fetching wishlist:', err));
  };

  const addToWishlist = async (itemId) => {
    if (!user) return alert('Please log in first!');
    
    try {
      const selectedItem = items.find((item) => item._id === itemId);
      if (!selectedItem) return;

      await axios.post(`http://localhost:4000/wishlist/add`, {
        bookId: selectedItem._id,
        title: selectedItem.title,
        itemImage: selectedItem.itemImage,
        userId: user.id,
        userName: user.name,
      }, { withCredentials: true });

      fetchWishlist(); 
    } catch (error) {
      console.error(error);
    }
  };

  const removeFromWishlist = async (itemId) => {
    if (!user) return;
    try {
      await axios.post(`http://localhost:4000/wishlist/remove`, { 
        itemId, 
        userId: user.id 
      }, { withCredentials: true });
      
      fetchWishlist(); 
    } catch (error) {
      console.error(error);
    }
  };

  // --- CRITICAL FIX HERE ---
  const isItemInWishlist = (itemId) => {
    return wishlist.some((wish) => {
      // 1. Check if the populated book object exists (it might be null if the book was deleted)
      if (!wish.bookId) return false;

      // 2. Check various ID possibilities safely using optional chaining (?.)
      return (
        wish.itemId === itemId || 
        wish.bookId === itemId || 
        wish.bookId?._id === itemId 
      );
    });
  };
  // -------------------------

  return (
    <div className="min-h-screen bg-[#f4ecd8] text-[#4b3e2e] font-serif">
      <Unavbar />
      <div className="container mx-auto px-4 py-8">
        <h2 className="text-3xl font-bold mb-8 text-center border-b-2 border-[#d6c7b3] pb-4 w-fit mx-auto">
            Browse Collection
        </h2>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {items.map((item) => {
            const correctImagePath = item.itemImage ? item.itemImage.replace(/\\/g, "/") : "";

            return (
              <div
                key={item._id}
                className="bg-[#fdfaf3] border border-[#e5dcc7] rounded-lg shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300 flex flex-col w-full"
              >
                <div className="relative group">
                  <img
                    src={`http://localhost:4000/${correctImagePath}`} 
                    alt="Item"
                    className="rounded-t-lg w-full h-72 object-cover" 
                  />
                  
                  <div className="absolute top-2 right-2 z-20">
                    {isItemInWishlist(item._id) ? (
                      <button
                        onClick={() => removeFromWishlist(item._id)}
                        className="bg-white p-2 rounded-full shadow hover:bg-gray-100 transition"
                        title="Remove from Wishlist"
                      >
                         <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="red" className="w-6 h-6 text-red-500">
                          <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z" />
                        </svg>
                      </button>
                    ) : (
                      <button
                        onClick={() => addToWishlist(item._id)}
                        className="bg-white p-2 rounded-full shadow hover:bg-gray-100 transition"
                        title="Add to Wishlist"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-gray-600">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
                        </svg>
                      </button>
                    )}
                  </div>

                  <Link to={`/uitem/${item._id}`}>
                      <div className="absolute inset-0 z-10 bg-transparent"></div>
                  </Link>
                </div>

                <div className="p-4 flex flex-col flex-grow z-10">
                  <h3 className="text-lg font-bold truncate mb-1" title={item.title}>
                      {item.title}
                  </h3>
                  <p className="text-sm text-gray-600 truncate">By {item.author}</p>
                  <div className="mt-auto pt-3 border-t border-[#eeeadd] flex justify-between items-center">
                      <span className="text-xl font-bold text-[#8b5e3c]">₹{item.price}</span>
                      
                      <Link
                          to={`/uitem/${item._id}`}
                          className="bg-[#6b4f3b] hover:bg-[#5b4230] text-white px-3 py-1 rounded text-sm font-medium transition"
                      >
                          View
                      </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default Products;









// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import Unavbar from './Unavbar';
// import { Link } from 'react-router-dom';

// function Products() {
//   const [items, setItems] = useState([]);
//   const [wishlist, setWishlist] = useState([]);
//   const user = JSON.parse(localStorage.getItem('user'));

//   useEffect(() => {
//     axios
//       .get(`http://localhost:4000/item`, { withCredentials: true })
//       .then((response) => {
//         setItems(response.data);
//       })
//       .catch((error) => {
//         console.error('Error fetching items:', error);
//       });

//     if (user) {
//       axios
//         .get(`http://localhost:4000/wishlist/${user.id}`, { withCredentials: true })
//         .then((response) => {
//           setWishlist(response.data);
//         })
//         .catch((err) => console.error('Error fetching wishlist:', err));
//     }
//   }, []);

//   const refreshWishlist = () => {
//     if (!user) return;
//     axios
//       .get(`http://localhost:4000/wishlist/${user.id}`, { withCredentials: true })
//       .then((response) => {
//         setWishlist(response.data);
//       })
//       .catch((err) => console.error('Error refreshing wishlist:', err));
//   };

//   const addToWishlist = async (itemId) => {

//     if (!user) {
//       alert('Please log in first!');
//       return;
//     }

//     try {
//       const selectedItem = items.find((item) => item._id === itemId);
//       if (!selectedItem) throw new Error('Item not found');

//       const { title, itemImage, _id } = selectedItem;

//       await axios.post(
//         `http://localhost:4000/wishlist/add`,
//         {
//           bookId: _id,
//           title,
//           itemImage,
//           userId: user.id,
//           userName: user.name,
//         },
//         { withCredentials: true }
//       );

//       refreshWishlist();
//     } catch (error) {
//       console.error('Error adding item to wishlist: ', error);
//     }
//   };

//   const removeFromWishlist = async (itemId) => {
//     if (!user) return;
//     try {
//       await axios.post(
//         `http://localhost:4000/wishlist/remove`,
//         { itemId, userId: user.id },
//         { withCredentials: true }
//       );

//       refreshWishlist();
//     } catch (error) {
//       console.error('Error removing item from wishlist: ', error);
//     }
//   };

//   const isItemInWishlist = (itemId) => {
//     return wishlist.some((wish) => wish.itemId === itemId);
//   };

//   return (
//     <div className="min-h-screen bg-[#f4ecd8] text-[#4b3e2e] font-serif">
//       <Unavbar />
//       <div className="container mx-auto p-6">
//         <h2 className="text-3xl font-bold mb-8 text-center">Books List</h2>
//         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 justify-items-center">
//           {items.map((item) => (
//             <div
//               key={item._id}
//               className="bg-[#fdfaf3] border border-[#e5dcc7] w-64 rounded-lg shadow hover:shadow-md transition duration-300"
//             >
//               <img
//                 src={`http://localhost:4000/${item.itemImage}`}
//                 alt="Item"
//                 className="rounded-t-lg object-cover"
//                 style={{ height: '200px', width: '100%' }}
//               />
//               <div className="p-3 space-y-1">
//                 <p className="text-base font-bold">{item.title}</p>
//                 <p className="text-sm">Author: {item.author}</p>
//                 <p className="text-sm">Genre: {item.genre}</p>
//                 <p className="text-[#6e4c2f] font-semibold">₹{item.price}</p>

//                 <div className="flex flex-wrap items-center gap-2 mt-3">
//                   {isItemInWishlist(item._id) ? (
//                     <button
//                       className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 text-sm rounded"
//                       onClick={() => removeFromWishlist(item._id)}
//                     >
//                       Remove
//                     </button>
//                   ) : (
//                     <button
//                       className="bg-[#6b4f3b] hover:bg-[#5b4230] text-white px-3 py-1 text-sm rounded"
//                       onClick={() => addToWishlist(item._id)}
//                     >
//                       Wishlist
//                     </button>
//                   )}
//                   <Link
//                     to={`/uitem/${item._id}`}
//                     className="bg-[#6b4f3b] hover:bg-[#5b4230] text-white px-3 py-1 text-sm rounded"
//                   >
//                     View
//                   </Link>
//                 </div>
//               </div>
//             </div>
//           ))}
//         </div>
//       </div>
//     </div>
//   );
// }

// export default Products;
