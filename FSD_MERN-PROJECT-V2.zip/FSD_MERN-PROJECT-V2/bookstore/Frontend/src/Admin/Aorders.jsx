import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Anavbar from './Anavbar'; // 1. Use Admin Navbar
import { FaTrash } from 'react-icons/fa';

const Aorders = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      // This hits the Admin route: router.get('/orders', authMiddleware, getAllOrders)
      const res = await axios.get('http://localhost:4000/orders', {
        withCredentials: true
      });
      setOrders(res.data);
    } catch (err) {
      console.error('Error fetching orders:', err);
    }
  };

  const deleteOrder = async (id) => {
    if(!window.confirm("Are you sure you want to delete this order?")) return;
    try {
      await axios.delete(`http://localhost:4000/userorderdelete/${id}`, {
        withCredentials: true
      });
      setOrders(orders.filter(order => order._id !== id));
      alert("Order deleted");
    } catch (err) {
      console.error(err);
      alert("Failed to delete order");
    }
  };

  const calculateStatus = (Delivery) => {
    const currentDate = new Date();
    const deliveryDate = new Date(Delivery);
    return deliveryDate >= currentDate ? "On The Way" : "Delivered";
  };

  return (
    <div className="min-h-screen bg-[#fdf6e3]">
      <Anavbar />
      
      <div className="container mx-auto p-6">
        <h2 className="text-3xl font-bold text-center text-[#4b3f2f] mb-8">
            Platform Order History
        </h2>

        {orders.length === 0 ? (
          <p className="text-center text-gray-600">No orders found.</p>
        ) : (
          <div className="grid gap-6">
            {orders.map((order) => {
              const status = calculateStatus(order.Delivery);
              return (
                <div key={order._id} className="bg-[#fffaf0] p-6 rounded-lg shadow border border-[#e0d8c3] flex flex-wrap justify-between items-center">
                  
                  {/* Image & Title */}
                  <div className="flex items-center gap-4 w-full md:w-auto mb-4 md:mb-0">
                    <img 
                      src={`http://localhost:4000/${order.itemImage}`} 
                      alt="book" 
                      className="w-16 h-20 object-cover rounded border"
                    />
                    <div>
                      <h4 className="font-bold text-lg text-[#4b3f2f]">{order.booktitle || order.itemname}</h4>
                      <p className="text-sm text-gray-600">Order ID: {order._id.slice(0, 10)}</p>
                    </div>
                  </div>

                  {/* Transaction Details */}
                  <div className="text-sm space-y-1 w-full md:w-auto mb-4 md:mb-0">
                    <p><strong>Buyer:</strong> {order.userName}</p>
                    <p><strong>Seller:</strong> {order.sellerName || "Unknown"}</p>
                    <p><strong>Date:</strong> {order.BookingDate}</p>
                  </div>

                  {/* Address */}
                  <div className="text-sm w-full md:w-1/4 mb-4 md:mb-0">
                     <p className="font-semibold">Shipping To:</p>
                     <p>{order.flatno}, {order.city}</p>
                     <p>{order.state} - {order.pincode}</p>
                  </div>

                  {/* Status & Action */}
                  <div className="flex flex-col items-end gap-2 w-full md:w-auto">
                    <p className="text-xl font-bold text-[#8B4513]">₹{order.totalamount}</p>
                    <span className={`px-3 py-1 rounded text-sm font-bold ${status === "Delivered" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}`}>
                        {status}
                    </span>
                    <button 
                        onClick={() => deleteOrder(order._id)}
                        className="text-red-600 hover:text-red-800 flex items-center gap-1 text-sm mt-2"
                    >
                        <FaTrash /> Delete
                    </button>
                  </div>

                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default Aorders;
