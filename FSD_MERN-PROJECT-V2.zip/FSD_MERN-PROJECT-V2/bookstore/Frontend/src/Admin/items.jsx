import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Anavbar from './Anavbar'; // 1. Changed from Unavbar to Anavbar
import { FaTrash } from 'react-icons/fa'; // Import Trash icon for admin actions

const Items = () => {
  const [items, setItems] = useState([]);

  // 2. Fetch items on load
  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = async () => {
    try {
      const res = await axios.get("http://localhost:4000/item");
      setItems(res.data);
    } catch (err) {
      console.error('Error fetching items:', err);
    }
  };

  // 3. Admin Function: Delete Item
  const deleteItem = async (id) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this book?");
    if (!confirmDelete) return;

    try {
      // Using the endpoint defined in your adminRoutes ('/useritemdelete/:id')
      await axios.delete(`http://localhost:4000/useritemdelete/${id}`, {
        withCredentials: true
      });
      alert("Item deleted successfully");
      // Refresh list
      setItems(items.filter(item => item._id !== id));
    } catch (err) {
      console.error("Error deleting item:", err);
      alert("Failed to delete item");
    }
  };

  return (
    <div className="min-h-screen bg-[#fdf6e3]">
      {/* 4. Render Admin Navbar */}
      <Anavbar /> 

      <div className="container mx-auto p-8">
        <h2 className="text-3xl font-bold mb-6 text-center text-[#4b3f2f]">
          All Books (Admin View)
        </h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {items.map((item) => (
            <div key={item._id} className="bg-[#fffaf0] p-4 rounded shadow border border-[#e0d8c3] relative">
              
              {/* Delete Button for Admin */}
              <button 
                onClick={() => deleteItem(item._id)}
                className="absolute top-2 right-2 text-red-600 hover:text-red-800 bg-white rounded-full p-2 shadow"
                title="Delete Book"
              >
                <FaTrash />
              </button>

              <img
                src={`http://localhost:4000/${item.itemImage}`}
                alt="Item"
                className="rounded-t-lg w-full object-cover border border-[#e0d8c3]"
                style={{ height: '250px' }}
              />
              
              <div className="mt-4 space-y-2 text-[#4b3f2f]">
                <p className="text-lg font-bold truncate" title={item.title}>{item.title}</p>
                <p className="text-sm">Author: {item.author}</p>
                <p className="text-sm">Genre: {item.genre}</p>
                <p className="text-sm">Seller: {item.sellerName}</p>
                <p className="text-[#8B4513] font-bold">Price: ₹{item.price}</p>
                
                <p className="text-xs text-gray-500 mt-2">
                    ID: {item._id}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Items;









// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import Unavbar from '../User/Unavbar';
// import { Link, useNavigate } from 'react-router-dom';

// const Items = () => {
//   const [items, setItems] = useState([]);
//   const [wishlist, setWishlist] = useState([]);
//   const navigate = useNavigate();

//   const handleAuthError = (err) => {
//     console.error(err);
//     if (err.response && err.response.status === 401) {
//       alert("Session expired. Please log in again.");
//       localStorage.removeItem("user");
//       navigate("/login");
//     }
//   };

//   useEffect(() => {
//     axios.get(`http://localhost:4000/item`)
//       .then((response) => setItems(response.data))
//       .catch((error) => console.error('Error fetching items:', error));

//     const user = JSON.parse(localStorage.getItem('user'));
//     if (user) {
//       axios.get(`http://localhost:4000/wishlist/${user.id}`, { withCredentials: true })
//         .then((response) => setWishlist(response.data))
//         .catch((error) => handleAuthError(error));
//     }
//   }, []);

//   const addToWishlist = async (itemId) => {
//     const selectedItem = items.find((item) => item._id === itemId);
//     if (!selectedItem) return alert('Item not found');

//     const user = JSON.parse(localStorage.getItem('user'));
//     if (!user) return alert("Please login to add items to wishlist");

//     const payload = { 
//       itemId: selectedItem._id, 
//       title: selectedItem.title, 
//       itemImage: selectedItem.itemImage, 
//       userId: user.id, 
//       userName: user.name 
//     };

//     try {
//       await axios.post(`http://localhost:4000/wishlist/add`, payload, { withCredentials: true });
//       setWishlist((prev) => [...prev, payload]);
//     } catch (error) {
//       handleAuthError(error);
//     }
//   };

//   const removeFromWishlist = async (itemId) => {
//     const user = JSON.parse(localStorage.getItem('user'));
//     if (!user) return alert("Please login to remove items from wishlist");

//     try {
//       await axios.post(`http://localhost:4000/wishlist/remove`, { itemId }, { withCredentials: true });
//       setWishlist((prev) => prev.filter((item) => item.itemId !== itemId));
//     } catch (error) {
//       handleAuthError(error);
//     }
//   };

//   const isItemInWishlist = (itemId) => {
//     return wishlist.some((item) => item.itemId === itemId);
//   };

// return (
//   <div>
//     <Unavbar />
//     <div className="container mx-auto p-8">
//       <h2 className="text-3xl font-semibold mb-4 text-center">Books List</h2>
//       <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
//         {items.map((item) => (
//           <div key={item._id} className="bg-white p-4 rounded shadow">
//             <img
//               src={`http://localhost:4000/${item.itemImage}`}
//               alt="Item"
//               className="rounded-t-lg w-full"
//               style={{ height: '350px', objectFit: 'cover' }}
//             />
//             <div className="mt-4 space-y-2">
//               <p className="text-xl font-bold">{item.title}</p>
//               <p className="text-gray-700">Author: {item.author}</p>
//               <p className="text-gray-700">Genre: {item.genre}</p>
//               <p className="text-blue-500 font-bold">Price: ${item.price}</p>

//               {/* Wishlist Button */}
//               {isItemInWishlist(item._id) ? (
//                 <button
//                   className="bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded"
//                   onClick={() => removeFromWishlist(item._id)}
//                 >
//                   Remove from Wishlist
//                 </button>
//               ) : (
//                 <button
//                   className="bg-purple-700 hover:bg-purple-800 text-white py-2 px-4 rounded"
//                   onClick={() => addToWishlist(item._id)}
//                 >
//                   Add to Wishlist
//                 </button>
//               )}

//               {/* View Button */}
//               <Link to={`/uitem/${item._id}`}>
//                 <button className="ml-4 bg-purple-700 hover:bg-purple-800 text-white py-2 px-4 rounded">
//                   View
//                 </button>
//               </Link>
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   </div>
// );
// }

// export default Items;
